package org.se1.anttest.model;

public class Lecture extends Course {

}
