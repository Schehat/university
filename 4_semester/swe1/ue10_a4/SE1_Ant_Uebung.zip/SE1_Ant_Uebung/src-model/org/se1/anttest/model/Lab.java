package org.se1.anttest.model;

public class Lab extends Course {

}
