export class Temperature{
    constructor(public grad: number){ }
}

