export class Student {
    public name: string;
    public nr: number;
    public subject: string;

    constructor(name: string, nr: number, subject: string) {
        this.name = name; 
        this.nr = nr; 
        this.subject = subject;
    }
}

