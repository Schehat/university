import { Component } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Student } from './student';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public students: Student[] = [ 
    new Student('Daisy', 47114711, 'MIN') ,
    new Student('Donald', 12345678, 'BIN') ,
    new Student('Goofy', 78563489, 'MDI') ,
    new Student('Trick', 13354712, 'BIN') ,
  ]

  displayedColumns: string[] = ['name',  'nr', 'subject', "details"];
 
  // erzeuge Datenquelle für die html-Tabelle:
  myTableData = new MatTableDataSource<Student>(this.students);

  getRecord(name: string){
    alert(name);
  }
}

