export class Converter {
    celsius: number;
    fahrenheit: number;

    constructor(celsius: number, fahrenheit: number){
        this.celsius = celsius;
        this.fahrenheit = fahrenheit;
    }
  }

