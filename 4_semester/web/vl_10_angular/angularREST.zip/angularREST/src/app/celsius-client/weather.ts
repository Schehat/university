export interface Weather {
    location: string;
    temperature: number;
  }

  