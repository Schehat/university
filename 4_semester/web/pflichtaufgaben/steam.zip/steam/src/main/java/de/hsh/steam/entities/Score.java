package de.hsh.steam.entities;

import java.io.Serializable;

/**
 * Enum Score
 */
public enum Score implements Serializable {

    bad,
    mediocre,
    good,
    very_good;

}
