package de.hsh.steam.entities;

import java.io.Serializable;

/**
 * Enum Streamingprovider
 */
public enum Streamingprovider implements Serializable {

    Netflix,
    AmazonPrime,
    Sky;

}
