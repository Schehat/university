# Pflichtaufgabe 1: User Interface und REST-Server

Listen Sie in dieser Markdown-Datei alle Mitglieder Ihrer Gruppe auf (Name, Vorname, Matrikelnummer) und beschreiben Sie kurz den Beitrag jedes einzelnen Mitglieds zur Lösung der Aufgabe. hier sollen Sie auch weitere allgemeine Informationen zu Ihrer Abgabe hinterlegen (z.B. Hinweise für den Test)

## Liste alle Mitglieder:

1. Lushaj, Detijon, 1630149
```
- 3.1 Wireframe
- 3.2. Umsetzung von HTML5 und CSS3
- 3.4. Entwurf einer REST-Schnittstelle
- 3.5. Entwicklung einer REST-Schnittstelle
    (UserResource, SeriesResource, RatingResource)
```

2. Abdel Kader, Schehat, 1630110
```
- 3.4. Entwurf einer REST-Schnittstelle
- 3.5. Entwicklung einer REST-Schnittstelle
    (UserResource, SeriesResource, RatingResource)
```

3. Aydin, Furkan, 1630039
```
- 3.5. Entwicklung einer REST-Schnittstelle
    (UserResource, SeriesResource)
```

4.  Mohamed, Aland 1630233
```
- 3.1 Wireframe
- 3.2. Umsetzung von HTML5 und CSS3
```