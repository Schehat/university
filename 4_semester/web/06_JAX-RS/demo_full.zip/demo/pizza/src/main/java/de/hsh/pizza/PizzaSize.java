package de.hsh.pizza;

public enum PizzaSize {
    S,
    M, 
    L, 
    XL,
    XXL
}
