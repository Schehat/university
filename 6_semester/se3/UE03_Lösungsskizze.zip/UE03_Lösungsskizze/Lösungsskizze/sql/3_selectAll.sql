SELECT * FROM person;
SELECT * FROM adresse;
SELECT * FROM wohnt_in;