import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
/**
 * Gruppe 03
 * @author Schehat
 * U18 Serialisierung
 */
public class Decode {
    /**
     * Deserialisierung einer dat Datei
     * @param path
     * @throws IOException
     * @throws ClassNotFoundException
     */
    @SuppressWarnings("resource")
    public static void decode(String path) throws IOException, ClassNotFoundException {
        FileInputStream fis = new FileInputStream(path);
        ObjectInputStream ois = new ObjectInputStream(fis);

        Object ob = ois.readObject();
        @SuppressWarnings("unchecked")
        ArrayList<Person> arr = (ArrayList<Person>)ob;
        
        for (int i = 0; i < arr.size(); i++) {
            System.out.println(arr.get(i).getName() + " mag " + arr.get(i).getBestFriend().getName());
        }
    }

    /**
     * client code
     * @param args
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        decode("friends.dat");
    }
}
