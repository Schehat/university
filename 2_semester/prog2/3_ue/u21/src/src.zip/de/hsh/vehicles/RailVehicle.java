package de.hsh.vehicles;
/**
 * 
 * @author Schehat
 *
 */
public interface RailVehicle extends Vehicle {
    public int trackGauge();
}
