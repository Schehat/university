package de.hsh.vehicles;
/**
 * 
 * @author Schehat
 *
 */
public interface Vehicle {
    public void operate();
}
