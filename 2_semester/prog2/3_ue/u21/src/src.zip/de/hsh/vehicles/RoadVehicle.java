package de.hsh.vehicles;

public interface RoadVehicle extends Vehicle {
    public int numberOfWheels();
}
