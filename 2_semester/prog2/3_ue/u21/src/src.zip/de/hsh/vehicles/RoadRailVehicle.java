package de.hsh.vehicles;

public interface RoadRailVehicle extends RoadVehicle, RailVehicle {

}
