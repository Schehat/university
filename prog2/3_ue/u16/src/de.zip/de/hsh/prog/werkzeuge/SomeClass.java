package de.hsh.prog.werkzeuge;
/**
 * @version 1.0
 * @author Schehat
 */
public class SomeClass {
    /**
     * @return ToString Methode ueberschrieben aud "This is SomeClass"
     */
    @Override public String toString() {
        return "This is SomeClass";
    }
}
