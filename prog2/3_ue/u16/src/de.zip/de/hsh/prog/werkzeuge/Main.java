package de.hsh.prog.werkzeuge;
/**
 * @version 1.0
 * @author Schehat
 */
public class Main {
    /**
     * Ruft die Main Methode auf die eine SomeClass erstellt und diese ausgibt
     * @see SomeClass
     * @param args
     */
    public static void main(String[] args) {
        SomeClass s= new SomeClass();
        System.out.println(s);
    }
}
