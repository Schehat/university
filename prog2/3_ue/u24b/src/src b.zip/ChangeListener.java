
public interface ChangeListener {
    void changed(ObservableProperty observable);
}
